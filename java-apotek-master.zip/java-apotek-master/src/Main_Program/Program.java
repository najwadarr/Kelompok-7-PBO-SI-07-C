package Main_Program;
import Form.Form_Login;
/**
 *
 * @author Rudiono
 */
public class Program {
    public static void main(String[] args){
        Form_Login login = new Form_Login();
        login.setVisible(true);
    }
}
